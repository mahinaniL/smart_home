import React, { useContext, useEffect, useState } from 'react';
import { RoomContext } from '../context/RoomContext';
import RoomCard from '../components/RoomCard';
import DeviceCard from '../components/DeviceCard';

export default function Dashboard() {
  const { rooms, selectedRoom } = useContext(RoomContext);
  const [weather, setWeather] = useState(null);

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return "Good Morning";
    if (h < 18) return "Good Afternoon";
    return "Good Evening";
  };

  useEffect(() => {
    fetch(\`https://api.openweathermap.org/data/2.5/weather?q=Delhi&appid=\${process.env.REACT_APP_WEATHER_KEY}&units=metric\`)
      .then(res => res.json())
      .then(data => setWeather(data.main.temp + '°C'))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold">{greeting()}, User 👋</h1>
      <p className="mt-2">Weather: {weather || 'Loading...'} | Energy: 12.5 kWh</p>

      <h2 className="mt-6 text-lg font-semibold">Rooms</h2>
      <div className="flex overflow-x-auto mt-2">
        {rooms.map(room => <RoomCard key={room.id} room={room} />)}
      </div>

      <h2 className="mt-6 text-lg font-semibold">{selectedRoom.name} Devices</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-2">
        {selectedRoom.devices.map(device => (
          <DeviceCard key={device.id} device={device} roomId={selectedRoom.id} />
        ))}
      </div>
    </div>
  );
}
