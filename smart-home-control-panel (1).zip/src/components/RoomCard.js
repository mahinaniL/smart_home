import React, { useContext } from 'react';
import { RoomContext } from '../context/RoomContext';

export default function RoomCard({ room }) {
  const { selectedRoom, setSelectedRoom } = useContext(RoomContext);
  const activeCount = room.devices.filter(d => d.status).length;

  return (
    <div
      onClick={() => setSelectedRoom(room)}
      className={\`m-2 p-4 w-40 h-28 rounded-xl text-white cursor-pointer bg-cover bg-center \${selectedRoom.id === room.id ? 'ring-4 ring-blue-500' : ''}\`}
      style={{ backgroundImage: \`url(\${room.image})\` }}
    >
      <h3 className="font-bold">{room.name}</h3>
      <p>{activeCount} device(s) on</p>
    </div>
  );
}
