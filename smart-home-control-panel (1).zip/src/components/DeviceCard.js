import React, { useContext } from 'react';
import { RoomContext } from '../context/RoomContext';

export default function DeviceCard({ device, roomId }) {
  const { toggleDevice } = useContext(RoomContext);

  return (
    <div className="p-4 border rounded-lg w-32 text-center shadow-md">
      <div className="text-3xl">{device.icon}</div>
      <div>{device.name}</div>
      <label className="flex items-center justify-center mt-2">
        <input
          type="checkbox"
          checked={device.status}
          onChange={() => toggleDevice(roomId, device.id)}
        />
        <span className="ml-2">{device.status ? 'ON' : 'OFF'}</span>
      </label>
    </div>
  );
}
